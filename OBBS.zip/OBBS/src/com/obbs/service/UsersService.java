package com.obbs.service;

import com.obbs.model.UsersPojo;


public interface UsersService {

	public int registerUser(UsersPojo usersPojo);

	
}
