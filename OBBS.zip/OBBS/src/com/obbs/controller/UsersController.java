package com.obbs.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.obbs.service.UsersService;
import com.obbs.model.UsersPojo;

@Controller
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@RequestMapping("/registerUsers")
	public String registerUser(HttpServletRequest request)
	{
	
		String firstName=request.getParameter("firstname");
		String lastName=request.getParameter("lastname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		int contactNumber=Integer.parseInt(request.getParameter("contactNumber"));
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		int weight=Integer.parseInt(request.getParameter("weight"));
		String state=request.getParameter("state");
		String area=request.getParameter("area");
		int pinCode=Integer.parseInt(request.getParameter("pincode"));
		String bloodGroup=request.getParameter("bloodGroup");
		
		UsersPojo usersPojo = new UsersPojo();
		usersPojo.setFirstName(firstName);
		usersPojo.setLastName(lastName);
		usersPojo.setAge(age);
		usersPojo.setGender(gender);
		System.out.println(gender);
		usersPojo.setContactNumber(contactNumber);
		usersPojo.setEmail(email);
		usersPojo.setPassword(password);
		usersPojo.setWeight(weight);
		usersPojo.setState(state);
		usersPojo.setArea(area);
		usersPojo.setPinCode(pinCode);
		usersPojo.setBloodGroup(bloodGroup);
		
		int id;
		int login;
		id = usersService.registerUser(usersPojo);
		if(id==1)
		{
			
			return "Success";
		}
		else
		{
			return "Failed";
		}
	}
}
