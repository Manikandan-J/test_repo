package com.obbs.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.UsersEntity;
import com.obbs.model.UsersPojo;

@Repository("usersDao")
public class UsersDaoImpl implements UsersDao {

	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();

			UsersEntity usersEntity = new UsersEntity();
			usersEntity.setFirstName(usersPojo.getFirstName());
			usersEntity.setLastName(usersPojo.getLastName());
			usersEntity.setAge(usersPojo.getAge());
			usersEntity.setGender(usersPojo.getGender());
			usersEntity.setContactNumber(usersPojo.getContactNumber());
			usersEntity.setEmail(usersPojo.getEmail());
			usersEntity.setPassword(usersPojo.getPassword());
			usersEntity.setWeight(usersPojo.getWeight());
			usersEntity.setState(usersPojo.getState());
			usersEntity.setArea(usersPojo.getArea());
			usersEntity.setPinCode(usersPojo.getPinCode());
			usersEntity.setBloodGroup(usersPojo.getBloodGroup());
			

			session.save(usersEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

}
