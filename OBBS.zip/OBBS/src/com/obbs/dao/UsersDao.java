package com.obbs.dao;

import com.obbs.model.UsersPojo;

public interface UsersDao {

	public int registerUser(UsersPojo usersPojo);

	
}
